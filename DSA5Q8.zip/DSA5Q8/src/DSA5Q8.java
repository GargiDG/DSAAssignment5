import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DSA5Q8 {
	
	public static int[] findOriginalArray(int[] changed) {
	    int n = changed.length;

	    if (n % 2 != 0) {
	        return new int[0]; // If the length is odd, it's not a doubled array
	    }

	    Map<Integer, Integer> countMap = new HashMap<>();

	    // Count the frequency of each number in the changed array
	    for (int num : changed) {
	        countMap.put(num, countMap.getOrDefault(num, 0) + 1);
	    }

	    List<Integer> originalList = new ArrayList<>();

	    // Check if each number in the changed array has a corresponding doubled number
	    for (int num : changed) {
	        if (countMap.getOrDefault(num, 0) == 0) {
	            continue; // Skip if the number has already been used
	        }

	        int doubledNum = 2 * num;

	        if (countMap.getOrDefault(doubledNum, 0) == 0) {
	            return new int[0]; // If a doubled number is not found, it's not a doubled array
	        }

	        originalList.add(num);

	        countMap.put(num, countMap.get(num) - 1); // Decrement the count of the number
	        countMap.put(doubledNum, countMap.get(doubledNum) - 1); // Decrement the count of the doubled number
	    }

	    int[] original = new int[originalList.size()];

	    // Convert the original list to an array
	    for (int i = 0; i < originalList.size(); i++) {
	        original[i] = originalList.get(i);
	    }

	    return original;
	}

	public static void main(String[] args) {
		int[] changed = {1, 3, 4, 2, 6, 8};

		int[] original = findOriginalArray(changed);

		// Printing the result
		for (int num : original) {
		    System.out.print(num + " ");
		}


	}

}
