
public class DSA5Q1 {
	public static int[][] construct2DArray(int[] original, int m, int n) {
	    int totalElements = m * n;
	    if (original.length != totalElements) {
	        return new int[0][0]; // Return an empty 2D array if it is impossible
	    }

	    int[][] result = new int[m][n];
	    int index = 0;

	    for (int i = 0; i < m; i++) {
	        for (int j = 0; j < n; j++) {
	            result[i][j] = original[index++];
	        }
	    }

	    return result;
	}

	public static void main(String[] args) {
		int[] original = {1, 2, 3, 4};
		int m = 2;
		int n = 2;

		int[][] result = construct2DArray(original, m, n);

		// Printing the result
		for (int i = 0; i < result.length; i++) {
		    for (int j = 0; j < result[i].length; j++) {
		        System.out.print(result[i][j] + " ");
		    }
		    System.out.println();
		}

	}

}
