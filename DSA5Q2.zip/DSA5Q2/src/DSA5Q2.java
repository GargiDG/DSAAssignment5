
public class DSA5Q2 {
	public static int arrangeCoins(int n) {
	    int rowCount = 0;
	    int coins = n;

	    while (coins >= rowCount + 1) {
	        rowCount++;
	        coins -= rowCount;
	    }

	    return rowCount;
	}

	public static void main(String[] args) {
		int n = 5;
		int completeRows = arrangeCoins(n);
		System.out.println(completeRows);


	}

}
