import java.util.Arrays;
public class DSA5Q3 {
	

	public static int[] sortedSquares(int[] nums) {
	    int[] result = new int[nums.length];

	    for (int i = 0; i < nums.length; i++) {
	        result[i] = nums[i] * nums[i];
	    }

	    Arrays.sort(result);

	    return result;
	}

	public static void main(String[] args) {
		int[] nums = {-4, -1, 0, 3, 10};
		int[] squaredArray = sortedSquares(nums);

		// Printing the result
		for (int num : squaredArray) {
		    System.out.print(num + " ");
		}


	}

}
